#!/usr/bin/env python3
import os
import pandas as pd

# Ensure this script runs in the directory containing your CSVs:
# If the script is elsewhere, adjust `script_dir` or os.chdir accordingly
script_dir = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
os.chdir(script_dir)

# List of CSV filenames (no headers present in the files themselves)
filenames = [
    "4_breastw.csv",
    "6_cardio.csv",
    "7_Cardiotocography.csv",
    "12_fault.csv",
    "21_Lymphography.csv",
    "29_Pima.csv",
    "30_satellite.csv",
    "31_satimage-2.csv",
    "33_skin.csv",
    "37_Stamps.csv"
]


def drop_last_column_inplace(path: str) -> None:
    """
    Reads a header-less CSV, drops its last column, and overwrites it without adding headers.
    """
    # Read without headers so all rows are data
    df = pd.read_csv(path, header=None)
    if df.shape[1] <= 1:
        print(f"⚠️  {path}: only {df.shape[1]} column(s), nothing to drop.")
        return

    # Drop the last column
    df_trimmed = df.iloc[:, :-1]

    # Write back without header or index
    df_trimmed.to_csv(path, header=False, index=False)
    print(f"✅  {path}: dropped column #{df.shape[1]} (now {df_trimmed.shape[1]} columns)")


if __name__ == "__main__":
    for fname in filenames:
        if os.path.isfile(fname):
            try:
                drop_last_column_inplace(fname)
            except Exception as e:
                print(f"❌  Error processing {fname}: {e}")
        else:
            print(f"❌  File not found: {fname}")
