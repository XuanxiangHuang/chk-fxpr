import json
import pandas as pd
import os
from types import SimpleNamespace
import math
import warnings
import resource
import numpy as np

# Suppress all warnings from XGBoost
warnings.filterwarnings('ignore', module='xgboost')

from pyxai import Learning, Explainer, Tools
from pyxai.sources.core.structure.type import EvaluationOutput
from pyxai.sources.core.structure.type import OperatorCondition

Tools.set_verbose(0)


def generate_wit(sample, expl, min_max_dict):
    """
    For each feature constraint, pick a value that VIOLATES the condition by at least ±1.0.
    - All features numeric (categoricals already encoded).
    - Uses ±1.0 pushes so booleans (0/1) snap after clamping.
    - If exact violation impossible within [min,max], fall back to nearest bound (best effort).
    expl: dict_features from to_features(details=True)
    """
    wit = sample.copy()

    def clamp(v, lo, hi):
        return max(lo, min(v, hi))

    def violate_single(op, thr, lo, hi):
        # Return a value in [lo, hi] that makes the predicate FALSE by >= 1.0 shift when possible.
        if op == OperatorCondition.LT:    # require v >= thr
            return clamp(thr + 1.0, lo, hi)
        if op == OperatorCondition.LE:    # require v >  thr
            return clamp(thr + 1.0, lo, hi)
        if op == OperatorCondition.GT:    # require v <= thr
            return clamp(thr - 1.0, lo, hi)
        if op == OperatorCondition.GE:    # require v <  thr
            return clamp(thr - 1.0, lo, hi)
        if op == OperatorCondition.EQ:    # require v != thr
            # try upward first, else downward
            v_up = clamp(thr + 1.0, lo, hi)
            return v_up if v_up != thr else clamp(thr - 1.0, lo, hi)
        if op == OperatorCondition.NEQ:   # require v == thr
            return clamp(thr, lo, hi)
        # Unknown operator: best effort, return threshold clamped
        return clamp(thr, lo, hi)

    def is_lower(op): return op in (OperatorCondition.GE, OperatorCondition.GT)
    def is_upper(op): return op in (OperatorCondition.LE, OperatorCondition.LT)

    for _, feats in expl.items():
        # Normalize: some codepaths may return a single dict
        if isinstance(feats, dict):
            feats = [feats]

        fid = feats[0]['id'] - 1  # to 0-based
        lo = float(min_max_dict[fid]['min'])
        hi = float(min_max_dict[fid]['max'])
        s  = float(sample[fid])

        lowers = []  # list of (thr, op) for GE/GT
        uppers = []  # list of (thr, op) for LE/LT
        eq_thr = None
        neq_thr = None

        for f in feats:
            op  = f.get('operator_sign_considered', f.get('operator'))
            thr = float(f['threshold'])
            if is_lower(op):
                lowers.append((thr, op))
            elif is_upper(op):
                uppers.append((thr, op))
            elif op == OperatorCondition.EQ:
                eq_thr = thr
            elif op == OperatorCondition.NEQ:
                neq_thr = thr

        # Pure EQ/NEQ single-literal cases
        if eq_thr is not None and not lowers and not uppers:
            v = violate_single(OperatorCondition.EQ, eq_thr, lo, hi)
        elif neq_thr is not None and not lowers and not uppers:
            v = violate_single(OperatorCondition.NEQ, neq_thr, lo, hi)

        # Interval or mixed bounds: go OUTSIDE the tightest interval using ±1.0
        elif lowers or uppers:
            candidates = []
            if lowers:
                # tightest lower is the max threshold
                L = max(t for t, _ in lowers)
                # go below lower bound by at least 1.0
                candidates.append(clamp(L - 1.0, lo, hi))
            if uppers:
                # tightest upper is the min threshold
                U = min(t for t, _ in uppers)
                # go above upper bound by at least 1.0
                candidates.append(clamp(U + 1.0, lo, hi))

            # choose the candidate closest to original sample (or the only one present)
            v = min(candidates, key=lambda x: abs(x - s)) if candidates else s

        else:
            # Single inequality literal: just violate it by ±1.0
            f0 = feats[0]
            v = violate_single(f0.get('operator_sign_considered', f0.get('operator')),
                               float(f0['threshold']), lo, hi)

        wit[fid] = v

    return wit


if __name__ == '__main__':
    # problematic: divorce, promoters, threeOf9, 42_WBC
    data_list = "datasets_bt.list"

    TIME_OUT = 60
    num = 50
    verbose = False

    datasets = []
    depths = []

    # Read the file
    with open(data_list, "r") as file:
        for line in file:
            parts = line.strip().split()  # Split by spaces
            dataset_path = parts[0]  # First part is the dataset path
            depth = int(parts[1])  # Second part is the depth (converted to int)

            datasets.append(dataset_path)
            depths.append(depth)

    for data_path, depth in zip(datasets, depths):
        base = os.path.splitext(os.path.basename(data_path))[0]
        df = pd.read_csv(f"bench/{base}/{base}.csv")
        feature_names = list(df.columns[:-1])
        target_name = df.columns[-1]
        num_features = len(feature_names)
        num_class = df[target_name].nunique()
        # Drop the last column (output column)
        df_X = df.iloc[:, :-1]
        # Extract min and max values for each feature
        min_values = df_X.min()
        max_values = df_X.max()
        # Create a dictionary with feature index as key
        min_max_dict = {i: {'min': min_values.iloc[i], 'max': max_values.iloc[i]} for i in range(df_X.shape[1])}

        if num_class > 2:
            continue

        data_filename = os.path.basename(data_path)

        if data_filename.split('.')[0] in ('divorce', 'promoters', 'threeOf9'):
            continue

        print(data_filename, depth, num_class)

        # 2. Load training hyperparameters
        with open(f"exported_bts/{base}/{base}_nbestim_{num}_maxdepth_{depth}_testsplit_0.2.params.json") as fp:
            param_dist = json.load(fp)
        param_dist.setdefault("num_class", num_class)

        # 3. Init learner & load the .model
        learner = Learning.Xgboost(
            f"bench/{base}/{base}.csv",
            learner_type=Learning.CLASSIFICATION,
            models_type=EvaluationOutput.BT
        )
        sk_model = learner.load_model(
            model_file=f"exported_bts/{base}/{base}_nbestim_{num}_maxdepth_{depth}_testsplit_0.2.model",
            learner_options=param_dist
        )

        # 4. Wrap into LearnerInformation-like object *with* feature_names, target_name
        info = SimpleNamespace(
            raw_model=sk_model,
            learner_options=param_dist,
            base_score=getattr(sk_model, "base_score", 0),
            feature_names=feature_names,
            target_name=target_name
        )
        learner.learner_information = [info]
        learner.n_features = num_features
        learner.n_labels   = num_class

        # 5. Convert & explain
        # bt_ensemble = learner.convert_model(output=EvaluationOutput.BT,learner_information=learner.learner_information)[0]
        bt_ensemble = learner.convert_model(learner_information=learner.learner_information)[0]

        output_str_axp = ''
        output_str_cxp = ''
        all_times_axp = []
        all_times_cxp = []
        good_wit = 0

        insts = np.loadtxt(f'extract_insts/{data_filename}', delimiter=',')
        for i, inst in enumerate(insts):

            explainer = Explainer.initialize(bt_ensemble, inst)
            # print(explainer.binary_representation)

            # print("i:", ','.join(f"{x}" for x in inst))
            output_str_axp += f"i: {','.join(f'{x}' for x in inst)}\n"
            output_str_cxp += f"i: {','.join(f'{x}' for x in inst)}\n"

            pred_i = bt_ensemble.predict_instance(inst)

            output_str_axp += f"pred: {pred_i}\n"
            output_str_cxp += f"pred: {pred_i}\n"

            # print("binary representation:", explainer.binary_representation)

            time_start_axp = (
                    resource.getrusage(resource.RUSAGE_SELF).ru_utime +
                    resource.getrusage(resource.RUSAGE_SELF).ru_stime +
                    resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime +
                    resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime
            )
            # we don't test AXp for BTs because of PyXAI have not implemented it yet
            axp = []
            # axp = explainer.sufficient_reason(time_limit=TIME_OUT)
            #
            # if len(axp):
            #     axp = explainer.to_features(axp, eliminate_redundant_features=True, details=True, without_intervals=True)
            #     axp = sorted({
            #         entry['id']
            #         for records in axp.values()
            #         for entry in records
            #     })

            time_end_axp = (
                    resource.getrusage(resource.RUSAGE_SELF).ru_utime +
                    resource.getrusage(resource.RUSAGE_SELF).ru_stime +
                    resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime +
                    resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime
            )

            time_start_cxp = (
                    resource.getrusage(resource.RUSAGE_SELF).ru_utime +
                    resource.getrusage(resource.RUSAGE_SELF).ru_stime +
                    resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime +
                    resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime
            )

            cxp = explainer.minimal_contrastive_reason(time_limit=TIME_OUT)
            wit_cxp = None

            if len(cxp):
                cxp = explainer.to_features(cxp, eliminate_redundant_features=True, details=True, contrastive=True, without_intervals=True)
                wit_cxp = generate_wit(inst, cxp, min_max_dict)

                cxp = sorted({
                    entry['id']
                    for records in cxp.values()
                    for entry in records
                })

            time_end_cxp = (
                    resource.getrusage(resource.RUSAGE_SELF).ru_utime +
                    resource.getrusage(resource.RUSAGE_SELF).ru_stime +
                    resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime +
                    resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime
            )

            rtime_axp = time_end_axp - time_start_axp
            rtime_cxp = time_end_cxp - time_start_cxp

            if len(axp) == 0:
                output_str_axp += f"expl: timeout\n"
                output_str_axp += f"s: None\n"
            else:
                output_str_axp += f"expl: {axp}\n"
                output_str_axp += f"s: {len(axp)}\n"

            if len(cxp) == 0:
                output_str_cxp += f"expl: timeout\n"
                output_str_cxp += f"s: None\n"
                output_str_cxp += f"wit: None\n"
                output_str_cxp += f"pred of wit: None\n"
            else:
                output_str_cxp += f"expl: {cxp}\n"
                output_str_cxp += f"s: {len(cxp)}\n"
                output_str_cxp += f"wit: {','.join(f'{x}' for x in wit_cxp)}\n"
                output_str_cxp += f"pred of wit: {bt_ensemble.predict_instance(wit_cxp)}\n"
                if bt_ensemble.predict_instance(wit_cxp) != pred_i:
                    good_wit += 1

            output_str_axp += f"rtime: {rtime_axp:.4f}\n\n"
            output_str_cxp += f"rtime: {rtime_cxp:.4f}\n\n"
            all_times_axp.append(rtime_axp)
            all_times_cxp.append(rtime_cxp)

        # output_str_axp += f"max time: {max(all_times_axp):.2f}\n"
        # output_str_axp += f"min time: {min(all_times_axp):.2f}\n"
        # output_str_axp += f"avg time: {np.mean(all_times_axp):.2f}\n"

        output_str_cxp += f"max time: {max(all_times_cxp):.2f}\n"
        output_str_cxp += f"min time: {min(all_times_cxp):.2f}\n"
        output_str_cxp += f"avg time: {np.mean(all_times_cxp):.2f}\n"

        # open(f"results/bts/abd/{data_filename.split('.')[0]}.{num}.log", 'w').write(output_str_axp)
        open(f"results/bts/con/{data_filename.split('.')[0]}.{num}.log", 'w').write(output_str_cxp)
        print("valid CXp wits: ", good_wit)
