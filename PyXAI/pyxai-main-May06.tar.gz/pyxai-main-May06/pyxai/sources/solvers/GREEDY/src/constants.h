//
// Created by audemard on 17/03/23.
//

#ifndef CMAKE_EXAMPLE_CONSTANTS_H
#define CMAKE_EXAMPLE_CONSTANTS_H
namespace pyxai {
    typedef enum tdtype {Classifier_BT, Classifier_RF, Regression_BT} Type;
}
#endif //CMAKE_EXAMPLE_CONSTANTS_H
