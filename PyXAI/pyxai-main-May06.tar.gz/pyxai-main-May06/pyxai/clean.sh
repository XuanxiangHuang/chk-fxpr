
rm -rf *.instance
rm -rf *.start
rm -rf build/
rm -rf solver_*
rm -rf *.xml
rm -rf *.pyc
rm -rf __pycache__
rm -rf *.*~
rm -rf temp/
