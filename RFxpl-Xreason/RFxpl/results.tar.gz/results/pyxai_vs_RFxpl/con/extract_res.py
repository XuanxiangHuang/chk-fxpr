import os
import csv

log_dir = "."  # Current directory
output_csv = "summary_valid.csv"

rows = []

for filename in sorted(os.listdir(log_dir)):
    if filename.endswith(".log"):
        dataset_name = filename[:-4]  # Remove '.log'
        filepath = os.path.join(log_dir, filename)

        # Default placeholder values
        valid = invalid = non_minimal = num_invalid_pyxai_wit = num_to = None

        try:
            with open(filepath, "r") as f:
                for line in f:
                    line = line.strip()
                    if line.startswith("nof. valid:"):
                        valid = int(line.split(":")[1].strip())
                    elif line.startswith("nof. invalid:"):
                        invalid = int(line.split(":")[1].strip())
                    elif line.startswith("nof. non-minimal:"):
                        non_minimal = int(line.split(":")[1].strip())
                    elif line.startswith("nof. invalid PyXAI's wit:"):
                        num_invalid_pyxai_wit = int(line.split(":")[1].strip())
                    elif line.startswith("nof. timeout:"):
                        num_to = int(line.split(":")[1].strip())
        except Exception as e:
            print(f"Warning: could not read log file {filepath}: {e}")

        # Compute total and percentages if counts are available
        if valid is not None and invalid is not None and non_minimal is not None and num_invalid_pyxai_wit is not None and num_to is not None:
            total = valid + invalid + non_minimal + num_to
            if total > 0:
                invalid_pct = f"{invalid / total * 100:.1f}%"
                valid_pct = f"{valid / total * 100:.1f}%"
                non_minimal_pct = f"{non_minimal / total * 100:.1f}%"
                num_invalid_pyxai_wit_pct = f"{num_invalid_pyxai_wit / total * 100:.1f}%"
                num_to_pct = f"{num_to / total * 100:.1f}%"

            else:
                invalid_pct = valid_pct = non_minimal_pct = num_invalid_pyxai_wit_pct = num_to_pct = "0.0%"
        else:
            # If any count is missing, mark as "N/A"
            invalid_pct = valid_pct = non_minimal_pct = num_invalid_pyxai_wit_pct = num_to_pct = "N/A"

        rows.append([
            dataset_name,
            invalid_pct,
            valid_pct,
            non_minimal_pct,
            num_invalid_pyxai_wit_pct,
            num_to_pct
        ])

# Write to CSV with reordered columns
with open(output_csv, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["dataset", "nof_invalid", "nof_valid", "nof_non_minimal", "num_invalid_pyxai_wit", "nof_timeout"])
    writer.writerows(rows)

print(f"Summary written to {output_csv}")
