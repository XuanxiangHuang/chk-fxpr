import os
import csv

log_dir = "."  # Current directory

rows = []

nof_calls = 0
nof_wits = 0
nof_proofs = 0
nof_buggy = 0

for filename in sorted(os.listdir(log_dir)):
    if filename.endswith(".log"):
        dataset_name = filename[:-4]  # Remove '.log'
        filepath = os.path.join(log_dir, filename)

        try:
            with open(filepath, "r") as f:
                for line in f:
                    line = line.strip()

                    if line.startswith("nof. wits: "):
                        raw = line[len("nof. wits: "):].strip()
                        if raw and raw.lower() != "none":
                            nof_wits += int(raw)

                    elif line.startswith("nof. proofs: "):
                        raw = line[len("nof. proofs: "):].strip()
                        if raw and raw.lower() != "none":
                            nof_proofs += int(raw)

                    elif line.startswith("nof. waxp calls: "):
                        raw = line[len("nof. waxp calls: "):].strip()
                        if raw and raw.lower() != "none":
                            nof_calls += int(raw)

                    elif line.startswith("nof. buggy: "):
                        raw = line[len("nof. buggy: "):].strip()
                        if raw and raw.lower() != "none":
                            nof_buggy += int(raw)
        except Exception as e:
            print(f"Warning: could not read log file {filepath}: {e}")

print("Total calls:", nof_calls)
print("Total wits:", nof_wits)
print("Total proofs:", nof_proofs)
print("Total buggy:", nof_buggy)
